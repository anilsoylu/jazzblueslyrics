import { NextRequest, NextResponse } from "next/server"

export function middleware(request: NextRequest) {
  const url = request.nextUrl.clone()
  const pathname = url.pathname
  const hostname = request.headers.get("host") || ""
  const wwwRegex = /^www\./

  const isDevelopment =
    hostname.includes("localhost:3000") || hostname.includes("127.0.0.1:3000")
  const isVercel = hostname.includes("vercel.app")

  const excludedPaths = [
    "/tr",
    "/_next",
    "/uploads",
    "/favicon.ico",
    "/images",
    "/robots.txt",
    "/sitemap.xml",
  ]

  if (!request.nextUrl.protocol.includes("https") && !isDevelopment) {
    const secureUrl = url.clone()
    secureUrl.protocol = "https:"
    return NextResponse.redirect(secureUrl, 301)
  }

  if (pathname === "/") {
    const trUrl = new URL("/tr", request.url)
    return NextResponse.redirect(trUrl, 301)
  }

  if (!wwwRegex.test(hostname) && !isDevelopment && !isVercel) {
    const wwwUrl = url.clone()
    wwwUrl.host = `www.${hostname}`
    return NextResponse.redirect(wwwUrl, 301)
  }

  if (
    excludedPaths.some(
      (path) => pathname === path || pathname.startsWith(path + "/")
    )
  ) {
    return NextResponse.next()
  }

  if (isDevelopment || isVercel) {
    if (
      !excludedPaths.some(
        (path) => pathname === path || pathname.startsWith(path + "/")
      )
    ) {
      const baseUrl = new URL("/", request.url)
      baseUrl.search = ""
      return NextResponse.redirect(baseUrl, 301)
    }
    return NextResponse.next()
  }

  if (pathname !== "/tr" && !pathname.startsWith("/tr/")) {
    const baseUrl = new URL("/tr", request.url)
    baseUrl.search = ""
    return NextResponse.redirect(baseUrl, 301)
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
}
