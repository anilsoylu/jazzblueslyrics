export const SECTION_IDS = {
  MY_COMPANIES: "my-companies",
  COMPANIES: "companies",
  TESTIMONIALS: "testimonials",
  FAQ: "faq",
} as const

export const SECTION_SPACING = "w-full py-3 md:py-6" as const
