export const sharedMetadata = {
  title: process.env.BASE_URL!,
  description: process.env.BASE_URL!,
  url: process.env.BASE_URL!,
  ogImage: {
    width: 1200,
    height: 630,
    type: "image/png",
  },
}
