export const metaData = {
  siteName: process.env.BASE_URL!,
  title: process.env.BASE_URL!,
  description: process.env.BASE_URL!,
  author: {
    name: process.env.BASE_URL!,
  },
  metaTitle:
    "Canlı ve Güvenilir Bahis Siteleri - Popüler ve Bonus Veren Siteler 2025",
  metaDescription:
    "Canlı bahis siteleri ve en iyi siteler listesi! Popüler, lisanslı bonus veren siteler burada. 2025'in güvenilir sitelerin kazadıran fırsatları için tıklayın.",
}
