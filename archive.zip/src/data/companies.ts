export const companies = [
  { id: 1, name: "BetMaster", userRating: 4.5, editorRating: 4.8 },
  { id: 2, name: "LuckySpin", userRating: 4.2, editorRating: 4.5 },
  { id: 3, name: "GoldenOdds", userRating: 4.7, editorRating: 4.9 },
  { id: 4, name: "BetKing", userRating: 4.0, editorRating: 4.3 },
  { id: 5, name: "SportsBet", userRating: 4.3, editorRating: 4.6 },
]
