export const articles = [
  {
    id: 1,
    title: "Dijital Pazarlamanın Geleceği",
    excerpt:
      "Yapay zeka ve büyük veri analizinin dijital pazarlamayı nasıl şekillendirdiğini keşfedin.",
  },
  {
    id: 2,
    title: "SEO Stratejileri 2025",
    excerpt:
      "Arama motorlarında üst sıralarda yer almanın yeni yolları ve trendleri.",
  },
  {
    id: 3,
    title: "Sosyal Medya Yönetimi İpuçları",
    excerpt:
      "Markanızı sosyal medyada etkili bir şekilde yönetmenin püf noktaları.",
  },
]
