export const CompanyNameData = process.env.BASE_URL!
export const siteTitles = {
  heroTitle: "Bahis Siteleri 2025",
  articleTitle: "2025 yılında öne çıkan popüler bahis siteleri",
  faqTitle: "Sıkça Sorulan Sorular",
}
