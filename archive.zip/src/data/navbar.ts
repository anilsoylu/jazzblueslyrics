export const MenuItemsData = [
  {
    label: "Anasayfa",
    href: "#header",
  },
]
