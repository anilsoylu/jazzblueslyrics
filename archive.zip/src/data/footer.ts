export const footerData = {
  companyName: process.env.BASE_URL!,
  year: new Date().getFullYear(),
  copyright: "Tüm hakları saklıdır.",
}
