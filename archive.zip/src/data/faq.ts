export const faqData = [
  {
    question: "Hangi bahis siteleri güvenilir?",
    answer:
      "Güvenilir bahis siteleri, global lisansa sahip, finansal açıdan hızlı ödeme yapan ve kullanıcı yorumları olumlu olan sitelerdir. Güvenilir bahis siteleri arasında Youwin, Bets10, 1xbet, Bahsegel, Tipobet ve MobilBahis gibi marka olmuş siteler yer almaktadır.",
  },
  {
    question: "Hangi bahis sitesi yasal?",
    answer:
      "Türkiye'de bahis sitesi açmak için Sportoto teşkilatı tarafından gerekli lisans ve izinlere sahip olunmalıdır. Bu yönergeye göre yasal bahis siteleri sadece Misli, Bilyoner, Oley, İddaa, Nesine ve Birebin siteleridir.",
  },
  {
    question: "Lisanslı bahis siteleri hangileri?",
    answer:
      "Dünya genelinde hizmet veren bahis sitelerinin Malta Gaming Authority ve Curacao eGaming gibi kuruluşlardan lisans alması gerekmektedir. Onwin, Sahabet, Betine, Efesbet ve Bankobet lisanslı bahis siteleri arasında yer almaktadır.",
  },
  {
    question: "En büyük bahis sitesi hangisi?",
    answer:
      "İsmini herkesin bildiği ve yakından takip ettiği en büyük bahis sitesi Bwin, Bet365, Superbahis, Tempobet, Matadorbet ve Başarıbet siteleridir.",
  },
  {
    question: "Deneme bonusu veren siteler nelerdir?",
    answer:
      "Deneme bonusu, bahis siteleri tarafından yeni üyelere sunulan en cazip bonustur. Çoğu zaman çevrim ya da yatırım şartı ile verilen deneme bonusu, ilk üyelere siteyi daha yakından tanıması ve vakit geçirmesi için sunulur. En yüksek deneme bonusu veren siteler; Fixbet, Xslot, Zbahis, Bettilt ve Starzbet'dir. Bu sitelerin bir kısmında çevrimsiz olarak deneme bonusu alabilirsiniz.",
  },
  {
    question: "Hangi bahis sitesi hediye veriyor?",
    answer:
      "Bahis siteleri potansiyel kullanıcılara ulaşmak ve onları üye yapmak için çeşitli hediyeler vermektedir. Hediye veren bahis sitelerine en çarpıcı örnek Vegabet, NakitBahis, Piabet, Kolaybet, Sekabet ve Liderbahis siteleridir.",
  },
]
