export type FooterNavbarItem = {
  label: string
  href: string
}
