export interface Testimonial {
  id: number
  name: string
  content: string
  rating: number
}
